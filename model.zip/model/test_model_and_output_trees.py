import pandas as pd
import numpy as np
import os
import joblib
from sklearn.tree import export_text, export_graphviz
from sklearn.metrics import accuracy_score, classification_report


def test_model(model, test_df, X_test, y_test, type):
    # Make predictions
    predictions = model.predict(X_test)

    # Evaluate the model
    accuracy = accuracy_score(y_test, predictions)
    print(f"Test Accuracy: {accuracy:.2f}")
    print("Classification Report:")
    print(classification_report(y_test, predictions))

    # Save results to a file
    test_df["predictions"] = predictions
    test_df["true_label"] = y_test
    test_df.to_csv(f"model/model/test_results_{type}.csv", index=False)
    print(f"Test results saved to model/model/test_results_{type}.csv.")

def output_trees(model, output_dir,X_test, y_test):
    os.makedirs(output_dir, exist_ok=True)
    # 存储预测正确的子模型
    correct_trees = []

    # 遍历随机森林中的所有子模型（决策树）
    for i, tree in enumerate(model.estimators_):
        # 使用子模型对测试集进行预测
        tree_predictions = tree.predict(X_test)
        
        # 检查该子模型是否对所有样本预测正确
        if (tree_predictions == y_test).all():
            print(f"Tree {i} predicts all test samples correctly!")
            correct_trees.append(tree)

            # 输出该树的规则（文本格式）
            tree_rules = export_text(tree, feature_names=list(X_test.columns))
            print(tree_rules)

            # 可视化（保存为 .dot 文件）
            dot_file = os.path.join(output_dir, f"correct_tree_{i}.dot")
            export_graphviz(
                tree,
                out_file=dot_file,
                feature_names=list(X_test.columns),
                class_names=["label_0", "label_1"],
                filled=True,
                rounded=True,
            )
            print(f"Tree {i} visualization saved to {dot_file}")

    # 检查预测正确的子模型数量
    print(f"Total number of correctly predicting trees: {len(correct_trees)}")


    
# Define directories and files
data_dir = "model/features/"
files = [f"aggregated_feature_{i}.csv" for i in range(15, 25)]  # File names for test samples
labels = [0, 0, 0, 1, 1, 1, 1, 1, 1, 1]  # Corresponding y_test values

# Load and combine test samples
dfs = [pd.read_csv(os.path.join(data_dir, file)) for file in files]
test_df = pd.concat(dfs, ignore_index=True)

# Ensure test data aligns with training features
significant_features = ['mean_of_mean_gradient', 'skewness', 'kurtosis', 
                        'mean_gradient_mean', 'mean_gradient_std', 'mean_gradient_max', 'max_gradient_mean']
X_test = test_df[significant_features]  # Select only the significant features
y_test = np.array(labels)  # Actual labels

type = 'randomtree'
# Load the trained model
model = joblib.load(f"model/model/trained_model_{type}_7_parameters_11.joblib")

test_model(model, test_df, X_test, y_test, type)
output_dir = "model/correct_trees/"
output_trees(model, output_dir, X_test, y_test)

